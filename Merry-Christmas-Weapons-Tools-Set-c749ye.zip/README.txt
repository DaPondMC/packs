Thank you for purchase

_______________________________________

Please review for this pack once you use it. Thank you very much

Follow me:
https://twitter.com/polygon_mc
https://www.instagram.com/polygony.std/
https://www.facebook.com/polygony.std
https://sketchfab.com/polygonymc

_______________________________________

If you encounter any issues, please contact me on Discord: chaaem

_______________________________________

Test on 1.20.2

For packs that include wings, hats, and backpacks, I recommend using the cosmetics plugin that I provide, which is CosmeticsCore. And for crates and keys, I suggest using plugins like random chest or ExcellentCrates.

Armor Set: You cannot change to a different set. It must be a leather set only because Leather Armor is a dyed set of various colors combined.

Some weapon models cannot be crafted into specific weapons, such as the trident, because the trident is a game-defined entity set as is.

